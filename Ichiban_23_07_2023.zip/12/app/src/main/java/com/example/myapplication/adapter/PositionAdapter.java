package com.example.myapplication.adapter;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.model.Position;
import com.example.myapplication.PositionPage;

import java.util.List;

public class PositionAdapter extends RecyclerView.Adapter<PositionAdapter.PositionViewHolder> {

    Context context;
    List<Position> Positions;

    public PositionAdapter(Context context, List<Position> Positions) {
        this.context = context;
        this.Positions = Positions;
    }

    @NonNull
    @Override
    public PositionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View positionItems = LayoutInflater.from(context).inflate(R.layout.position_layout, parent, false);
        return new PositionViewHolder(positionItems);
    }

    @Override
    public void onBindViewHolder(@NonNull PositionViewHolder holder, int position) {

        int imageId = context.getResources().getIdentifier("ic_" + Positions.get(position).getImg(), "drawable", context.getPackageName());

        holder.imagePosition.setImageResource(imageId);
        holder.namePosition.setText(Positions.get(position).getNamePosition());
        holder.descPosition.setText(Positions.get(position).getDescPosition());
        holder.pricePosition.setText(String.valueOf(Positions.get(position).getPrice()));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, PositionPage.class);

                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
                        (Activity) context,
                        new Pair<View, String>(holder.itemView, "positionImage")

                        );

                intent.putExtra("imagePosition", imageId);
                intent.putExtra("namePosition", Positions.get(position).getNamePosition());
                intent.putExtra("descPosition", Positions.get(position).getDescPosition());
                intent.putExtra("pricePosition", String.valueOf(Positions.get(position).getPrice()));
                intent.putExtra("kcal", Positions.get(position).getKcal());
                intent.putExtra("weight", Positions.get(position).getWeight());
                intent.putExtra("positionID", Positions.get(position).getId());

                context.startActivity(intent, options.toBundle());
            }
        });
    }

    @Override
    public int getItemCount() {
        return Positions.size();
    }

    public static final class  PositionViewHolder extends RecyclerView.ViewHolder{

        ImageView imagePosition;
        TextView namePosition, pricePosition, descPosition, kcal, weight;

        public PositionViewHolder(@NonNull View itemView) {
            super(itemView);

            imagePosition = itemView.findViewById(R.id.imagePosition);
            namePosition = itemView.findViewById(R.id.namePosition);
            descPosition = itemView.findViewById(R.id.descPosition);
            pricePosition = itemView.findViewById(R.id.pricePosition);
            kcal = itemView.findViewById(R.id.kcal);
            weight = itemView.findViewById(R.id.weight);

        }

    }
}
