package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myapplication.model.Order;
import com.example.myapplication.model.Position;

import java.util.ArrayList;
import java.util.List;

public class OrderPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_page);

        ListView order_list = findViewById(R.id.order_list);

        List<String> positionsTitle = new ArrayList<>();
        for(Position c : MainActivity.fullpositionList) {
            if(Order.items_id.contains(c.getId()))
                positionsTitle.add(c.getNamePosition());
        }

        order_list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, positionsTitle));


    }

    public void openBasket(View view) {
        Intent intent = new Intent(this, OrderPage.class);
        startActivity(intent);
    }

    public void BackInMenu(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}