package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.adapter.CategoryAdapter;
import com.example.myapplication.adapter.PositionAdapter;
import com.example.myapplication.model.Category;
import com.example.myapplication.model.Position;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView categoryRecycler, positionRecycler;
    CategoryAdapter categoryAdapter;
    static PositionAdapter positionAdapter;
    static List<Position> positionList = new ArrayList<>();
    static List<Position> fullpositionList = new ArrayList<>();

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Категории блюд

        List<Category> categoryList = new ArrayList<>();
        categoryList.add(new Category(1," Сашими "));
        categoryList.add(new Category(2," Суши Нигири "));
        categoryList.add(new Category(3," Суши Гункан "));
        categoryList.add(new Category(4," Суши ассорти "));
        categoryList.add(new Category(5," Роллы "));
        categoryList.add(new Category(6," Блюда с крабом "));
        setCategoryRecycler(categoryList);

        // Категории блюд

        //List<Position> positionList = new ArrayList<>();
        positionList.add(new Position(1,500, "cat1_tuna", "Сашими Тунец", "Сашими из тунца в пряном соусе – это вкусное японское блюдо. Эффектный внешний вид и возбуждающие аппетит свойства делают его отличным аппетайзером.", "orange", "450 kcal", "300 g",1));
        positionList.add(new Position(2,600, "cat1_octo", "Сашими Осьминог", "Лучшего качества осьминог", "black", "450 kcal", "300 g",1));
        positionList.add(new Position(3,550, "cat1_perch", "Сашими Окунь", "Сашими из свежего тунца", "black", "450 kcal", "300 g",1));
        positionList.add(new Position(4,450, "cat1_salmon", "Сашими Лосось", "Сашими из свежего тунца", "black", "450 kcal", "300 g",1));
        positionList.add(new Position(5,700, "cat1_unagi", "Сашими Угорь", "Сашими из свежего тунца", "black", "450 kcal", "300 g",1));
        positionList.add(new Position(6,750, "cat1_aburi", "Сашими Абури\nШиме-саба", "Сашими из свежего тунца", "black", "450 kcal", "300 g",1));

        positionList.add(new Position(7,750, "cat2_salmon", "Лосось", "Сашими из свежего тунца", "black", "450 kcal", "300 g",2));
        positionList.add(new Position(8,750, "cat2_salmoncheese", "Лосось с сыром", "Сашими из свежего тунца", "black", "450 kcal", "300 g",2));
        positionList.add(new Position(9,750, "cat2_shrimp", "Креветки", "Сашими из свежего тунца", "black", "450 kcal", "300 g",2));

        fullpositionList.addAll(positionList);
        setPositionRecycler(positionList);

    }

    public void openBasket(View view) {
        Intent intent = new Intent(this, OrderPage.class);
        startActivity(intent);
    }

    private void setCategoryRecycler(List<Category> categoryList) {

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);

        categoryRecycler = findViewById(R.id.categoryRecycler);
        categoryRecycler.setLayoutManager(layoutManager);

        categoryAdapter = new CategoryAdapter(this, categoryList);
        categoryRecycler.setAdapter(categoryAdapter);
    }

    private void setPositionRecycler(List<Position> positionList) {

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);

        positionRecycler = findViewById(R.id.positionRecycler);
        positionRecycler.setLayoutManager(layoutManager);

        positionAdapter = new PositionAdapter(this, positionList);
        positionRecycler.setAdapter(positionAdapter);

    }

    public static void showCategory(int category){
        positionList.clear();
        positionList.addAll(fullpositionList);

        List<Position> filterPositions = new ArrayList<>();

        for(Position p : positionList){
            if(p.getCategory() == category)
                filterPositions.add(p);
        }

        positionList.clear();
        positionList.addAll(filterPositions);

        positionAdapter.notifyDataSetChanged();
    }
}