package com.example.myapplication.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Order {

    //public static List<Integer> items_id = new
    public static Set<Integer> items_id = new HashSet<>();
}
