package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.model.Order;

public class PositionPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_position_page);



        ImageView imagePosition = findViewById(R.id.imagePagePosition);
        TextView namePosition = findViewById(R.id.namePagePosition);
        TextView descPosition = findViewById(R.id.descPagePosition);
        TextView pricePosition = findViewById(R.id.pricePagePosition);
        TextView kcal = findViewById(R.id.kcal);
        TextView weight = findViewById(R.id.weight);


        imagePosition.setImageResource(getIntent().getIntExtra("imagePosition", 0));
        namePosition.setText(getIntent().getStringExtra("namePosition"));
        descPosition.setText(getIntent().getStringExtra("descPosition"));
        pricePosition.setText(getIntent().getStringExtra("pricePosition"));
        kcal.setText(getIntent().getStringExtra("kcal"));
        weight.setText(getIntent().getStringExtra("weight"));
    }

    public void addToCard(View view){

        int item_id = getIntent().getIntExtra("positionID",0);
        Order.items_id.add(item_id);
        Toast.makeText(this,"Добавлено!", Toast.LENGTH_LONG).show();

    }

    public void openBasket(View view) {
        Intent intent = new Intent(this, OrderPage.class);
        startActivity(intent);
    }

    public void BackInMenu(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}