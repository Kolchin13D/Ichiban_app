package com.example.myapplication.model;

public class Position {

    int id, price, category;
    String img, namePosition, descPosition, color, weight, kcal;

    public Position(int id, int price, String img, String namePosition, String descPosition, String color, String kcal, String weight, int category) {
        this.id = id;
        this.price = price;
        this.img = img;
        this.namePosition = namePosition;
        this.descPosition = descPosition;
        this.color = color;
        this.kcal = kcal;
        this.weight = weight;
        this.category = category;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getNamePosition() {
        return namePosition;
    }

    public void setNamePosition(String namePosition) {
        this.namePosition = namePosition;
    }

    public String getDescPosition() {
        return descPosition;
    }

    public void setDescPosition(String descPosition) {
        this.descPosition = descPosition;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getKcal() {
        return kcal;
    }

    public void setKcal(String kcal) {
        this.kcal = kcal;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }
}
